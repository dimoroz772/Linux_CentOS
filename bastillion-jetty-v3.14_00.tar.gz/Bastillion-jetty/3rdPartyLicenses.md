Third party licenses by different vendors:
=========================================

Apache Commons Codec : Apache License, Version 2.0 - The Apache Software Foundation

Apache Commons Configuration : Apache License, Version 2.0 - The Apache Software Foundation

Apache Commons DBCP2 : Apache License, Version 2.0 - The Apache Software Foundation

Apache Commons FileUpload : Apache License, Version 2.0 - The Apache Software Foundation

Apache Commons Lang : Apache License, Version 2.0 - The Apache Software Foundation

Apache Commons Log4j 2 : Apache License, Version 2.0 - The Apache Software Foundation

Bootstrap : MIT License - Twitter, Inc.

Google-Gson : Apache License, Version 2.0 - Google, Inc.

H2 : Mozilla Public License, Version 2.0 - H2 Group

Jetty : Apache License, Version 2.0 - The Eclipse Foundation

JSch (mwiede) : BSD License - Atsuhiko Yamanaka - JCraft,Inc, Matthias Wiedemann, Jeremy Norris

jquery.floatThead : MIT License - Misha Koryak

jQuery : MIT License - jQuery Foundation, Inc.

jQueryUI : MIT License - jQuery Foundation, Inc.

Popper : MIT License - Floating UI Contributors

SLF4J : MIT License - QOS.ch

Thymeleaf: Apache License, Version 2.0 -  The THYMELEAF team

xterm.js : MIT License - The xterm.js Authors

ZXing : Apache License, Version 2.0 -  ZXing Authors