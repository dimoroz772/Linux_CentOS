# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 3.13.x  | :white_check_mark: |

## Reporting a Vulnerability

If you’ve found a vulnerability, we would like to know so we can patch it.

You can report security issues by sending an email to support@bastillion.io.
